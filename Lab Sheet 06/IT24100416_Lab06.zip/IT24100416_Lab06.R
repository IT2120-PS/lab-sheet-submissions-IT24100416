setwd("C:\\Users\\MSI\\Desktop\\IT24100416")

#Exercise 1
#(i)Distribution:X~Binomial(n = 50, p = 0.85)
#(ii). Probability that at least 47 students passed:

1 - pbinom(46, size = 50, prob = 0.85)


#Exercise 2
#(i)Random variable X: number of calls received in one hour.
#(ii)Distribution: X~Poisson(λ = 12)
#(iii)Probability exactly 15 calls in an hour:

dpois(15, lambda = 12)
